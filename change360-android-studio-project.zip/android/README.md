# CHANGE360 Android Studio Build & Deployment Guide

## How to Build in Android Studio
1. Open Android Studio Koala / Ladybug.
2. Select File > Open and pick the 'android' folder.
3. Gradle will automatically sync with libs.versions.toml.
4. Click Run (Shift + F10) to run on Pixel 8 emulator or connected phone.

## Build Installable APK
Run in terminal:
```bash
./gradlew assembleRelease
```
Output APK is created at: `app/build/outputs/apk/release/app-release.apk`

## Build Google Play App Bundle (AAB)
Run in terminal:
```bash
./gradlew bundleRelease
```
Upload `app/build/outputs/bundle/release/app-release.aab` to the Google Play Console.