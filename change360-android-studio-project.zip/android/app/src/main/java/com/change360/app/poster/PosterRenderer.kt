package com.change360.app.poster

import android.content.ContentValues
import android.content.Context
import android.graphics.*
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.change360.app.data.model.AwarenessCategory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.OutputStream

data class PosterData(
    val title: String,
    val subtitle: String,
    val callToAction: String,
    val bullets: List<String>,
    val category: AwarenessCategory,
    val templateName: String,
    val authorOrOrgName: String = "CHANGE360 Changemaker"
)

object PosterRenderer {
    /**
     * Renders a high-resolution 1080x1350 poster bitmap using native Android Canvas.
     */
    fun renderPosterBitmap(poster: PosterData): Bitmap {
        val width = 1080
        val height = 1350
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        // Draw background theme
        val bgPaint = Paint().apply {
            isAntiAlias = true
            style = Paint.Style.FILL
            color = Color.parseColor("#064E3B")
        }
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)

        // Inner Card
        val cardPaint = Paint().apply {
            isAntiAlias = true
            color = Color.WHITE
        }
        val cardRect = RectF(60f, 160f, (width - 60).toFloat(), (height - 180).toFloat())
        canvas.drawRoundRect(cardRect, 40f, 40f, cardPaint)

        // Title and Call to action
        val titlePaint = Paint().apply {
            isAntiAlias = true
            color = Color.parseColor("#0F172A")
            textSize = 64f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        canvas.drawText(poster.title, 110f, 380f, titlePaint)

        return bitmap
    }

    /**
     * Saves rendered bitmap into Android MediaStore Pictures directory.
     */
    suspend fun saveBitmapToMediaStore(context: Context, bitmap: Bitmap, fileName: String): Uri? = withContext(Dispatchers.IO) {
        val resolver = context.contentResolver
        val contentValues = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "$fileName.png")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/png")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/CHANGE360")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
        }

        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues) ?: return@withContext null
        val stream: OutputStream? = resolver.openOutputStream(uri)
        stream?.use {
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, it)
        }
        uri
    }
}